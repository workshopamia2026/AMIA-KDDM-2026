# Calibration Cases

Synthetic examples for testing only.

## Reporting artifact
Reported medication errors rise after a new reporting interface. Consider true harm and easier ascertainment. Request denominators, severity, report volume, interface use, workflow observations, and prior trends. Do not conclude the interface caused more errors.

## Single-cause blame
A delayed result acknowledgment precedes deterioration. Preserve it as a candidate contributor while examining notification design, escalation policy, staffing, handoffs, alert volume, result criticality, patient trajectory, and whether earlier acknowledgment could plausibly change the outcome. Do not infer negligence.

## Reverse causation
Patients receiving intensive monitoring have worse outcomes. Consider that severity prompted monitoring. Do not interpret monitoring as harmful without an appropriate design.

## Multifactorial workflow
Barcode scanning compliance declines. Consider scanner availability, label readability, network reliability, exceptions, workload, staffing, training, workflow mismatch, workarounds, and measurement changes.

## Evidence preservation
An intermittent clinical interface failure may have hidden results. Prioritize system logs, interface messages, audit trails, timestamps, downtime notices, and user reports before logs roll over. Separate containment from attribution.
