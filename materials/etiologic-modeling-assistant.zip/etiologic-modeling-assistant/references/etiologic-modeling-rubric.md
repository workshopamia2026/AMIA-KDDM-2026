# Etiologic Modeling Rubric

## Outcome and time
- Distinguish observation from interpretation.
- Define severity, scope, detection method, baseline, comparator, and measurement uncertainty.
- Require contributors to precede the outcome or fit a credible latency.
- Do not mistake consequences for causes.

## Mechanistic coherence
For every material hypothesis require a plausible pathway, explicit assumptions, supporting and contradictory evidence, observable indicators, and possible interactions.

## Systems coverage
Consider relevant patient/population, disease/treatment, clinician/team, workflow/task, technology/data, environment/equipment, staffing/organization, and external factors without requiring every level in every case.

## Alternative explanations
Check confounding, reverse causation, mediation, effect modification, selection/collider bias, surveillance and reporting changes, measurement/coding changes, regression to the mean, secular trends, co-interventions, coincidence, and multifactorial mechanisms.

## Evidence calibration
Use qualitative, justified status. Do not invent causal probabilities. Bradford Hill considerations inform but do not prove causation. Missing evidence is not automatically negative evidence.

## Action and boundary
Separate immediate safety from causal conclusions. Prefer proportionate and reversible actions with monitoring. Avoid punitive action from an unconfirmed model. Escalate estimands, DAGs, adjustment sets, effect estimation, and counterfactual claims to Causal Inference.
