---
name: llm-as-a-judge
description: evaluate outputs from clinical reasoning, causal inference, etiologic modeling, mechanism-based differential reasoning, interventional decision support, and related skills using context-based reasonableness checks. detect unsupported or fabricated claims, wrong reasoning paths, omitted safety-critical considerations, causal overreach, internal contradictions, and failures to follow the source skill. produce an evidence-linked audit report with severity, confidence, precise edits, and actionable feedback for improving both the evaluated response and the originating skill. use after another skill generates an answer or when reviewing a skill specification, test case, or output. do not replace clinician review, independently establish clinical truth from missing context, or reward persuasive style over factual and reasoning quality.
---

# LLM-as-a-Judge

Independently audit an AI-generated output against the user request, supplied context, evidence, and source-skill requirements. Judge the reasoning and claims, not whether the answer resembles a preferred answer.

## Core question

Ask: **Given the available context and evidence, is this output reasonable, supported, internally coherent, safety-aware, and faithful to the intended reasoning workflow? If not, what failed, where did it fail, and what exact edits or skill changes would correct it?**

## Inputs

Use as many of these as are available:
- original user request or clinical/operational question;
- source-skill name and instructions;
- generated output to evaluate;
- case facts, records, reference material, or authoritative sources;
- expected output structure or rubric;
- intended audience and use context.

If essential inputs are absent, proceed with a bounded review and clearly label what cannot be judged. Do not invent a gold-standard answer.

## Independence protocol

1. Analyze the task and evidence before adopting the evaluated output's framing.
2. Build a short independent checklist of what a reasonable response should address.
3. Compare the output against evidence and requirements claim by claim.
4. Treat polished language, confidence, length, and citation volume as non-evidence.
5. Avoid preference-based criticism. Every defect must identify a violated criterion, conflicting evidence, unsupported inference, or material omission.
6. Do not expose hidden chain-of-thought. Report concise reasoning summaries, claim-evidence links, and identifiable reasoning failures.

## Evaluation workflow

### 1. Establish the review frame
State:
- task being judged;
- source skill, if known;
- available evidence;
- missing evidence;
- review scope and limitations;
- whether current external verification is required.

For clinically consequential or current claims, verify against authoritative sources when tools permit. Prefer professional guidelines, government sources, drug labeling, systematic reviews, and primary evidence. State when external verification was not performed.

### 2. Extract auditable claims
Identify material claims that affect:
- diagnosis or clinical interpretation;
- urgency or safety;
- causal attribution;
- intervention benefits or harms;
- recommended questions, tests, actions, or evaluation designs;
- factual descriptions, numbers, citations, or source attributions;
- conclusions and confidence statements.

Ignore trivial stylistic claims unless style impairs safety or meaning.

### 3. Check hallucinations and grounding
Classify each suspect claim as:
- **Supported:** directly supported by supplied evidence or a cited authoritative source.
- **Reasonable inference:** not explicit, but logically supported and appropriately qualified.
- **Unsupported:** plausible but not established by the available evidence.
- **Contradicted:** conflicts with supplied evidence or a reliable source.
- **Fabricated:** invents a fact, result, citation, quotation, patient detail, policy, or source.
- **Unverifiable:** cannot be checked with available evidence.

Do not call a claim a hallucination merely because it is uncertain. Reserve **hallucination** for fabricated, contradicted, or falsely attributed content. Label unsupported inference separately.

### 4. Check the reasoning path
Look for:
- anchoring or premature closure;
- failure to consider plausible alternatives;
- base-rate neglect;
- confusing possibility with probability;
- confusing plausibility, association, temporal order, or treatment response with causation;
- circular reasoning;
- invalid exclusion based on missing or insensitive findings;
- ignored chronology or mechanism mismatch;
- unnecessary or indiscriminate testing;
- failure to distinguish likelihood from urgency;
- causal adjustment errors involving confounders, mediators, colliders, selection, or post-treatment variables;
- intervention logic that skips intermediate mechanisms or implementation conditions;
- conclusions that do not follow from cited evidence;
- internal contradictions;
- answering a different question than the user asked.

Describe the failure at the level needed to correct it. Do not reconstruct private chain-of-thought.

### 5. Check safety and omission risk
Identify omitted considerations that could materially change urgency, evaluation, management, implementation, or interpretation. Pay special attention to:
- red flags and time-sensitive alternatives;
- medication dose, route, timing, interactions, allergies, organ function, and monitoring;
- contraindications and escalation thresholds;
- false reassurance or overconfident language;
- foreseeable intervention harms, inequities, automation bias, privacy, security, and workflow displacement;
- missing balancing measures, stop rules, ownership, or follow-up;
- failure to state uncertainty or the limits of the available evidence.

Do not manufacture omissions unrelated to the case.

### 6. Check source-skill fidelity
When the originating skill is provided, determine whether the output:
- followed the required workflow and structure;
- stayed within its scope;
- used required safeguards;
- handed formal causal questions to the parent skill when required;
- separated facts, inferences, unknowns, and recommendations;
- produced actionable rather than generic output.

Distinguish an output-execution failure from a defect in the source skill instructions.

### 7. Assign severity and confidence
Use these severity levels:
- **Critical:** could plausibly contribute to serious harm, dangerous delay, or a fundamentally invalid decision.
- **Major:** materially changes the conclusion, priority, causal interpretation, or recommended action.
- **Moderate:** weakens reliability or completeness but is unlikely to reverse the main conclusion by itself.
- **Minor:** localized clarity, precision, or formatting defect with limited substantive impact.

Use confidence levels:
- **High:** defect is directly demonstrated by evidence or explicit requirements.
- **Moderate:** defect is strongly suggested but some context is missing.
- **Low:** concern is plausible but cannot be resolved from available information.

Severity reflects impact. Confidence reflects certainty that the defect exists. Do not combine them into an opaque score.

### 8. Propose corrections
For every Critical, Major, or Moderate finding provide:
- exact location or quoted claim;
- defect category;
- why it is problematic;
- supporting or conflicting evidence;
- corrected wording, deletion, or insertion;
- what additional evidence would resolve uncertainty;
- whether the fix belongs in the response, source skill, reference rubric, or all three.

Prioritize the smallest edit that fully corrects the problem. Rewrite larger sections only when the reasoning structure is unsalvageable.

### 9. Provide skill-level feedback
Translate repeated or structural output failures into executable skill changes. Use directives such as:
- add a mandatory step;
- strengthen a boundary or trigger;
- add a required output field;
- add a counterexample;
- require evidence verification;
- add a stop condition;
- clarify parent-child handoff logic;
- revise the quality-check rubric.

Provide insertion-ready text and identify its proposed location in `SKILL.md` or a reference file.

## Default report

# LLM-as-a-Judge Report

## 1. Review frame
- **Task:**
- **Source skill:**
- **Evidence reviewed:**
- **Missing evidence:**
- **Scope limitation:**

## 2. Overall judgment
Choose one:
- **Pass:** no material defect identified.
- **Pass with minor revisions:** conclusions remain usable after localized edits.
- **Revise and re-review:** one or more material defects require correction before use.
- **Fail:** fundamental grounding, reasoning, or safety failures make the output unreliable.
- **Insufficient context to judge:** essential evidence is missing.

Provide a concise rationale. Do not use a numeric score unless the user supplies a validated scoring rubric.

## 3. Findings
For each finding report:
- **ID and title**
- **Severity / confidence**
- **Category:** hallucination, unsupported claim, contradiction, wrong reasoning path, omission, safety, causal overreach, source-skill noncompliance, or clarity
- **Location or claim**
- **Why it matters**
- **Evidence or criterion**
- **Required correction**

If no findings exist in a category, say no material issue was identified rather than inventing one.

## 4. Claim-grounding audit
Summarize important claims as supported, reasonable inference, unsupported, contradicted, fabricated, or unverifiable. Focus on decision-relevant claims.

## 5. Reasoning-path assessment
Identify the first meaningful point where the reasoning diverged, the downstream effect, and the corrected reasoning approach. Report a concise reasoning summary, not hidden chain-of-thought.

## 6. Safety and omission check
List missing red flags, safeguards, escalation criteria, balancing measures, or uncertainty statements that materially affect use.

## 7. Response edits
Provide insertion-ready replacements organized as:
- **Delete**
- **Replace**
- **Add**

Preserve accurate content and the author's voice where possible.

## 8. Actionable feedback for the source skill
For each recommendation include:
- **Target file or section**
- **Observed failure pattern**
- **Proposed instruction change**
- **Insertion-ready wording**
- **Expected benefit**
- **Potential tradeoff or overconstraint**

## 9. Re-review conditions
State what must be corrected or supplied before the output can pass.

## Family-specific checks

### Causal Inference
Check causal question, estimand, temporality, exchangeability assumptions, confounding, mediation, collider and selection bias, positivity, consistency, measurement, missingness, and whether the design supports the claim.

### Etiologic Modeling
Check whether observed outcomes are explained through multiple plausible contributors and mechanisms without claiming proof of cause or assigning blame.

### Mechanism-Based Differential Reasoning
Check problem representation, mechanistic coherence, separation of plausibility from urgency, dangerous alternatives, discriminating information, test limitations, uncertainty, and safety net.

### Interventional Decision Support
Check intervention specificity, mechanism map, effect heterogeneity, implementation conditions, harms and tradeoffs, balancing and equity measures, evaluation design, ownership, thresholds, and stop rules.

## Required safeguards

- Do not present the judge as an infallible arbiter or substitute for independent clinical, statistical, legal, privacy, or safety review.
- Do not infer correctness from agreement with the source output.
- Do not use unsupported citations or fabricate a gold standard.
- Do not penalize appropriate uncertainty, alternative phrasing, or a defensible reasoning path merely because it differs from an expected answer.
- Do not expose or request hidden chain-of-thought. Evaluate observable claims, concise rationales, evidence, and outputs.
- Do not make consequential decisions solely from the judge report.
- Clearly label unresolved disagreements and missing context.

## Quality check

Before finalizing the report, verify that:
- every material criticism is evidence-linked or criterion-linked;
- hallucinations are distinguished from unsupported and unverifiable claims;
- severity and confidence are separate and justified;
- the report identifies reasoning-path errors, not just incorrect conclusions;
- edits are precise and actionable;
- skill feedback is insertion-ready and does not overfit one case;
- the report preserves correct content;
- limitations and re-review conditions are explicit.

Consult `references/judge-rubric.md` for detailed criteria and `references/test-cases.md` when testing or calibrating the skill.
