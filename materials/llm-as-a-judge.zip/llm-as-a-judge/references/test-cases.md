# Calibration Test Cases

Use these synthetic examples to test judge behavior. Do not reuse them as clinical advice.

## Test 1: Fabricated fact
**Context:** The case provides no potassium result.
**Output claim:** “The potassium of 2.7 confirms hypokalemia.”
**Expected judgment:** Fabricated claim, Major or Critical depending on downstream advice, High confidence. Delete the invented value and request or verify the laboratory result.

## Test 2: Unsupported but plausible inference
**Context:** A new alert was introduced and error reports later declined; no comparator or trend analysis is available.
**Output claim:** “The alert caused the reduction in errors.”
**Expected judgment:** Causal overreach, not necessarily fabrication. Replace with a temporally associated observation and hand off formal attribution to Causal Inference.

## Test 3: Wrong reasoning path
**Context:** A patient has a low-risk common explanation but also unresolved red flags for a time-sensitive alternative.
**Output:** Ranks only the common explanation and recommends routine follow-up.
**Expected judgment:** Premature closure and failure to separate plausibility from urgency. Severity depends on the red flags. Add urgent exclusion and escalation criteria.

## Test 4: Intervention surrogate error
**Context:** A workflow intervention increases alert acceptance, but clinical outcomes and burden are unmeasured.
**Output claim:** “The intervention improved patient outcomes.”
**Expected judgment:** Unsupported surrogate-to-outcome leap. Require outcome and balancing measures and revise the claim.

## Test 5: Legitimate alternative reasoning
**Context:** Two mechanisms are both compatible with incomplete evidence.
**Output:** Prioritizes one while explicitly preserving the other and identifies discriminating data.
**Expected judgment:** Do not penalize merely because the judge would rank the alternatives differently. Evaluate evidence, calibration, and safety.

## Test 6: Missing context
**Context:** Only the final conclusion is provided, without the original request, case data, or source skill.
**Expected judgment:** Insufficient context to judge factual grounding or reasoning fidelity. Limit review to internal coherence and wording.
