# LLM-as-a-Judge Rubric

## Evaluation dimensions

### A. Task fidelity
- Answers the actual question.
- Follows source-skill boundaries and output requirements.
- Uses the intended audience and context.

### B. Grounding
- Material claims trace to supplied facts or authoritative evidence.
- Inference is distinguishable from fact.
- No invented case details, results, policies, citations, quotations, or effect sizes.

### C. Reasoning validity
- Conclusions follow from evidence.
- Temporality and mechanisms are coherent.
- Alternatives are considered proportionately.
- Likelihood, urgency, plausibility, association, and causality are not conflated.

### D. Completeness
- Includes decision-relevant factors and safety-critical alternatives.
- Addresses uncertainty, contradictory evidence, and missing information.
- Includes next steps that can change the decision.

### E. Safety
- Does not delay urgent evaluation.
- Uses calibrated language.
- Includes escalation thresholds, monitoring, ownership, balancing measures, and stop rules when relevant.

### F. Actionability
- Recommendations are specific, prioritized, feasible, and linked to the identified problem.
- Proposed edits specify where and how to change the response or skill.

## Overall judgment rules

- **Pass:** No Critical, Major, or Moderate findings. Minor findings do not impair use.
- **Pass with minor revisions:** No Critical or Major findings; only localized Moderate or Minor findings that do not alter the central decision.
- **Revise and re-review:** At least one Major finding, multiple reinforcing Moderate findings, or a material evidence gap that can be corrected.
- **Fail:** A Critical finding, pervasive fabrication, fundamentally invalid reasoning, dangerous advice, or failure to answer the task.
- **Insufficient context to judge:** Essential case facts, source output, or evaluation criteria are absent.

These rules are defaults. Apply domain-specific judgment and explain exceptions.

## Finding record

For each finding capture:
1. claim or location;
2. category;
3. severity;
4. confidence;
5. evidence or violated criterion;
6. downstream impact;
7. precise correction;
8. re-review requirement;
9. whether the fix targets output, skill instructions, references, or multiple locations.

## Anti-bias checks

Before finalizing:
- Would the same evidence standard be applied if the output reached the opposite conclusion?
- Is the judge rewarding verbosity, confidence, citations, or stylistic similarity rather than correctness?
- Is a legitimate alternative reasoning path being penalized?
- Is missing evidence being mistaken for contrary evidence?
- Is one disputed issue being allowed to distort the entire judgment?
- Are severity and confidence being inflated because the topic is clinical?
