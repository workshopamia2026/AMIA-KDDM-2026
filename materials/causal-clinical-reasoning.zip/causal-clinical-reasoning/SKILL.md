---
name: causal-clinical-reasoning
description: Design, prototype, test, or teach causal clinical reasoning assistants for education, research, quality improvement, or workflow design. Use for etiologic modeling, mechanism-based differential diagnosis, or interventional decision-support prototypes, especially when the work needs causal reasoning, clinical-safety guardrails, clear uncertainty, fairness checks, and a reusable agent or skill specification. Do not use for direct patient care, definitive diagnosis, prescribing, or processing identifiable health information.
---

# Causal Clinical Reasoning

Create safe prototypes that help users structure a clinical question; never present the prototype as a clinical decision-maker.

## Operating boundary

- Work only with fictional, synthetic, or appropriately de-identified cases. Do not ask for, retain, or expose protected health information.
- State that outputs support education, research, workflow design, or clinician review—not independent diagnosis or treatment.
- Do not turn an association, temporal sequence, or generated explanation into a causal claim.
- Treat local policy, current evidence, clinical judgment, and appropriate escalation as controlling.
- Stop and advise immediate local clinical evaluation for emergency symptoms, instability, or high-risk uncertainty.

## Choose the pathway

Use the requester’s stated goal. If it is not explicit, ask one concise question and offer these choices:

1. **Etiologic modeling** — What may be causing or contributing to an outcome?
2. **Differential diagnosis** — What explanations should be considered and what evidence would distinguish them?
3. **Interventional decision support** — What options should be evaluated, under what conditions, and with what tradeoffs?

Use `references/templates-and-cases.md` for the workshop-ready starter case, prompts, and evaluation checklist.

## Build workflow

### 1. Frame the problem

Capture, or make explicit assumptions about:

- the population, setting, intended user, and intended decision;
- the outcome of interest and time horizon;
- known facts, unknown facts, and sources of information;
- the appropriate unit of analysis: individual, group, workflow, or population.

Do not silently fill clinical gaps. List missing information that could materially change the analysis.

### 2. Apply causal and mechanistic reasoning

For etiologic questions, organize the answer as `candidate contributor → plausible mechanism → outcome`. Then identify alternative pathways, confounders, mediators, selection effects, and evidence that would strengthen or weaken the proposed explanation.

For differential questions, create a concise problem representation, then organize possible explanations by mechanism, likelihood, severity, and distinguishing evidence. Separate likely, possible, and urgent-to-exclude conditions.

For intervention questions, define the outcome and decision point before discussing options. Present conditional considerations rather than directives. Identify eligibility conditions, contraindications, tradeoffs, monitoring, and data required before a clinician acts.

### 3. Produce a reusable prototype

When asked for an agent, skill, prompt, or chatbot, produce these sections in this order:

1. **Purpose and intended user**
2. **In-scope questions and out-of-scope uses**
3. **Instructions or system prompt**
4. **Structured output format**
5. **Suggested conversation starters**
6. **Synthetic test cases**
7. **Evaluation checklist**

Adapt the system-prompt pattern in the reference rather than relying on generic medical-chatbot wording. Keep it concise enough to be used in a workshop or prototype.

### 4. Evaluate and revise

Evaluate every prototype against the following before describing it as ready for testing:

- Does it identify the decision and intended use?
- Does it distinguish observed information, assumptions, mechanisms, and unknowns?
- Does it avoid causal overclaiming?
- Does it name information needed to verify or refine the answer?
- Does it avoid definitive diagnostic or treatment direction?
- Does it specify clinician review, escalation, and data-handling boundaries?
- Does it surface fairness, bias, transportability, and workflow-fit concerns?

If the answer fails any item, revise the instructions or output schema and retest with a synthetic case.

## Implementation extensions

Only discuss retrieval, workflow automation, EHR integration, or interface design as a prototype architecture unless the requester provides an approved environment and governance requirements.

- For retrieval, specify approved sources, update ownership, citation display, and behavior when evidence is absent or conflicting.
- For EHR-connected concepts, specify data minimization, role-based access, auditability, human review, and clear separation between draft support and clinical action.
- For user interfaces, foreground uncertainty, source visibility, missing data, escalation cues, and the clinician’s final decision.

Do not claim regulatory compliance. Describe validation and governance requirements as items to be reviewed by the relevant organization.
