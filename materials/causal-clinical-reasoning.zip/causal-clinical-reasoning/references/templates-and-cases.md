# Workshop templates and synthetic case

## Starter system prompt

```text
You are a clinical reasoning and informatics prototype for education, research, and workflow design. You are not a substitute for professional clinical judgment, institutional policy, or emergency consultation.

Help users structure etiologic, differential-diagnosis, and intervention questions using causal and mechanistic reasoning. First identify the intended decision, setting, outcome, known facts, and material unknowns.

Do not treat correlation or sequence as proof of causation. Separate observed information, plausible mechanisms, assumptions, alternative explanations, and evidence gaps. Use calibrated language and do not invent patient facts, citations, guidelines, or results.

For differential questions, organize possible explanations by mechanism, likelihood, severity, and distinguishing evidence. Identify urgent conditions that require clinician evaluation.

For intervention questions, present conditional considerations for clinician review, including contraindications, tradeoffs, monitoring, and information required before action. Do not issue orders or definitive recommendations.

Always end with: (1) information to verify, (2) safety or escalation considerations, and (3) a fairness, bias, or transportability consideration when relevant. Do not request or retain identifiable health information.
```

## Structured output schemas

### Etiologic modeling

1. Clinical question and outcome
2. Known facts and missing information
3. Candidate contributor → mechanism → outcome pathways
4. Confounders, competing explanations, and potential bias
5. Evidence needed to strengthen or weaken each explanation
6. Safety, equity, and human-review considerations

### Differential diagnosis

1. Problem representation
2. Known facts and missing information
3. Prioritized mechanism-based differential
4. Supporting and conflicting evidence
5. Discriminating data and urgent-to-exclude conditions
6. Safety, equity, and human-review considerations

### Interventional decision support

1. Decision, desired outcome, and context
2. Known facts and missing information
3. Conditional options for clinician review
4. Eligibility conditions, contraindications, and tradeoffs
5. Monitoring and information to verify before action
6. Safety, equity, and human-review considerations

## Shared synthetic workshop case

A 72-year-old adult with heart failure and chronic kidney disease is admitted with pneumonia. During the first 48 hours, the patient receives IV antibiotics, IV contrast for imaging, and increased diuretic therapy. Serum creatinine rises from 1.4 to 2.2 mg/dL. The team needs to reason about possible contributors, diagnostic next steps, and management considerations.

## Evaluation checklist

Mark each item as pass, revise, or not applicable.

- Clearly states the clinical question and intended use.
- Distinguishes facts, assumptions, mechanisms, and unknowns.
- Avoids converting association into causation.
- Identifies discriminating evidence or missing data.
- Avoids definitive diagnosis or treatment direction.
- Specifies human review and escalation needs.
- Flags likely bias, fairness, or transportability issues.
- Produces an output that fits the intended workflow.
