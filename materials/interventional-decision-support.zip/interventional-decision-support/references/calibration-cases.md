# Calibration Cases

## Alert acceptance surrogate
Alert acceptance rises, but patient outcomes and workload are unmeasured. Do not infer clinical benefit. Require outcome and balancing measures.

## Workflow displacement
A new intake checklist improves completion but delays urgent triage. Treat timeliness as a balancing measure and define a stop rule.

## Unequal reach
A portal intervention improves follow-up among enrolled users. Examine digital access, language, disability, enrollment selection, and offline alternatives before generalizing.

## Implementation failure
A sound intervention shows no effect during a period of low fidelity. Distinguish theory failure from implementation failure and measure reach, dose, fidelity, and context.

## Temporal association
Errors decline after implementation without a comparator. Describe the association, consider trends and co-interventions, and hand causal attribution to Causal Inference.
