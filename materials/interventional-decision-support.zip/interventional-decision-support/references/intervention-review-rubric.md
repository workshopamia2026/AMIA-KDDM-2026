# Intervention Review Rubric

## Intervention specificity
Require components, responsible roles, recipients, workflow location, timing, dose/frequency/duration, comparator, resources, and dependencies. Reject vague labels such as “education,” “alert,” “AI,” or “workflow redesign.”

## Mechanistic coherence
Require a plausible component-to-outcome pathway, observable intermediate changes, coherent timing, explicit assumptions, contextual dependencies, failure pathways, and harmful mechanisms.

## Evidence fit
Assess separately evidence that the mechanism exists, the intervention activates it, the mechanism affects the outcome, findings transfer to the local setting, and implementation is feasible.

## Implementation readiness
Review acceptability, adoption, appropriateness, feasibility, fidelity, implementation cost, penetration/reach, and sustainability. Identify accountable owners and minimum infrastructure.

## Safety, burden, and equity
Assess patient and workforce safety, cognitive and documentation burden, false positives/negatives, workarounds, risk displacement, privacy, security, governance, opportunity cost, accessibility, differential effects, and downstream consequences.

## Evaluation readiness
Require operational definitions, baseline, process/outcome/balancing/implementation/equity measures, comparator, follow-up, data-quality checks, analysis of trends and co-interventions, and predefined modify/scale/pause/stop thresholds.

## Decision classification
Use one: design refinement; limited pilot with safeguards; proceed after gaps are addressed; substantial revision; or do not proceed. State evidence, assumptions, safeguards, and thresholds.

## Causal boundary
Escalate causal estimands, DAGs, adjustment sets, effect estimation, and formal confounding, mediation, selection, or collider analysis to the parent Causal Inference skill.
