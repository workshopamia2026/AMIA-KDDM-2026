---
name: interventional-decision-support
description: evaluate proposed clinical, informatics, patient-safety, quality-improvement, or workflow interventions by clarifying intended outcomes, mapping mechanisms and assumptions, identifying who may benefit or be harmed, specifying implementation conditions, examining tradeoffs and unintended consequences, and creating an evaluation and monitoring plan. use for intervention design, theory of change, workflow redesign, clinical decision support, implementation planning, pilot design, and preimplementation review. do not guarantee effectiveness, prescribe patient-specific treatment, or claim causal effects without appropriate evidence.
---

# Interventional Decision Support

Evaluate whether a proposed intervention is coherent, plausible, implementable, equitable, and evaluable before presenting it as a solution.

## Core question

Ask: **Could a proposed clinical or workflow intervention plausibly improve the intended outcome, through what mechanism, for whom, under what conditions, and with what tradeoffs?**

## Governing distinctions

Keep four questions separate:
1. **Plausibility:** Could the intervention work through a defensible mechanism?
2. **Evidence:** What evidence supports the intervention and mechanism?
3. **Implementation:** Can it be delivered with fidelity in this setting?
4. **Causality:** Can an observed change be attributed to the intervention?

Do not treat plausibility, feasibility, adoption, or temporal improvement as proof of causal effectiveness.

## Workflow

1. **Check safety first.** Identify risks of delayed care, automation bias, unsafe workarounds, inequity, privacy or security failure, and risk displacement. State stop conditions and safeguards before benefits.
2. **Specify the decision.** Clarify whether the user must explore, design, pilot, implement, scale, modify, pause, or discontinue.
3. **Specify the intervention.** Define components, responsible roles, recipients, workflow location, timing, frequency, intensity, duration, resources, and comparator/current state.
4. **Define outcomes.** Specify target population, setting, primary outcome, meaningful-change criterion, time horizon, measurement method, process outcomes, implementation outcomes, and balancing measures.
5. **Map mechanisms.** Trace **component → immediate response → intermediate mechanism → behavior/workflow change → intended outcome**. For each link list assumptions, evidence, contextual dependencies, observable indicators, and failure modes.
6. **Examine heterogeneity.** Identify who may benefit, benefit less, or be harmed across patient, clinician, unit, and setting characteristics. Consider severity, comorbidity, language, disability, digital access, health literacy, staffing, role, readiness, and infrastructure when relevant. Do not invent subgroup effects.
7. **Assess implementation conditions.** Evaluate workflow fit, usability, workload, staffing, training, leadership, governance, technical reliability, interoperability, data quality, downtime readiness, privacy, security, cost, sustainability, fidelity, and justified adaptation.
8. **Analyze tradeoffs.** Consider clinical harm, false positives and negatives, alert fatigue, cognitive and documentation burden, bottlenecks, workarounds, deskilling, overreliance, opportunity cost, inequity, perverse incentives, and downstream effects.
9. **Review evidence.** Distinguish evidence for the mechanism, the specific intervention, transferability, and implementation feasibility. Use current authoritative guidance and evidence when tools permit. State when external evidence was not checked.
10. **Design evaluation.** Match rigor to risk, uncertainty, reversibility, and scale. Include baseline, comparator, process, outcome, balancing, implementation, and equity measures; data-quality checks; follow-up; monitoring frequency; and decision thresholds. Consider simulation, usability testing, phased rollout, pilot, interrupted time series, controlled before-and-after, stepped-wedge, or randomized designs as appropriate.
11. **Make a bounded recommendation.** Choose: proceed to design refinement; limited pilot with safeguards; proceed after specified gaps; revise substantially; or do not proceed in the proposed form. State conditions, owners, monitoring, stop rules, and uncertainties.
12. **Hand off formal causal questions.** Send causal estimands, DAGs, adjustment sets, effect estimation, and formal confounding, mediation, selection, or collider analyses to the parent Causal Inference skill.

## Required safeguards

- Do not guarantee benefit or convert systems analysis into patient-specific treatment advice.
- Do not infer clinical benefit from adoption, compliance, clicks, documentation, or alert acceptance alone.
- Do not recommend material-risk implementation without balancing measures, ownership, monitoring, and stop conditions.
- Do not fabricate local resources, effects, costs, staffing, evidence, guidelines, or citations.
- Separate facts, user assumptions, external evidence, inference, and unknowns.
- Prefer reversible staged testing when uncertainty or potential harm is substantial.

## Default output

### Decision and intervention
State the decision, components, target users/population, setting, workflow location, and comparator.

### Intended outcomes
State the primary outcome, intermediate/process outcomes, time horizon, measurement method, and meaningful-change criterion.

### Mechanism map
For each pathway report the component, proposed mechanism, assumptions, contextual conditions, indicators, and failure modes.

### Who may benefit, benefit less, or be harmed
Describe plausible heterogeneity and equity implications without inventing subgroup data.

### Implementation requirements
List minimum workflow, staffing, training, technology, governance, data, privacy, and sustainability requirements.

### Tradeoffs and unintended consequences
Separate likely burdens, serious risks, opportunity costs, and downstream effects.

### Evidence and uncertainty
State what is supported, inferred, unknown, and requires current external verification.

### Evaluation and monitoring plan
Include process, outcome, balancing, implementation, and equity measures; baseline and comparator; monitoring frequency; owners; and criteria to stop, modify, scale, or discontinue.

### Bounded recommendation
Select one decision classification and explain conditions and unresolved uncertainties.

### Causal Inference handoff
When needed provide intervention, comparator, population, setting, outcome, time horizon, mechanisms, effect modifiers, possible confounders/mediators/moderators/colliders/selection, co-interventions, trends, data limitations, causal question, and candidate designs.

## Quality check

Confirm that the response specifies the intervention, maps mechanisms, separates plausibility/evidence/implementation/causality, addresses heterogeneity and tradeoffs, includes balancing and equity measures, selects proportionate evaluation, defines ownership and stop rules, avoids unsupported effectiveness claims, and hands formal causal analysis to the parent skill.

Consult `references/intervention-review-rubric.md` for complex, high-risk, or system-wide proposals.
