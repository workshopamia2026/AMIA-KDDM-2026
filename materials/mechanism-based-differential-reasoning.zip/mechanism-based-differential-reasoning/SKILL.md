---
name: mechanism-based-differential-reasoning
description: support mechanism-based differential reasoning for uncertain clinical presentations by building a concise problem representation, generating and comparing plausible mechanistic explanations, identifying dangerous or time-sensitive conditions that remain urgent to exclude, and selecting high-value information that would distinguish among alternatives. use for clinical simulations, case discussions, diagnostic reasoning education, working differentials, questions to ask, and test-selection reasoning. do not use to claim a definitive diagnosis, replace licensed clinical judgment, or delay emergency evaluation.
---

# Mechanism-Based Differential Reasoning

Use this workflow to make the reasoning visible rather than merely naming a likely diagnosis.

## Core question

Ask: **What mechanisms could explain this uncertain clinical presentation, what makes each explanation more or less plausible, what remains urgent to exclude, and what additional information would most meaningfully distinguish among alternatives?**

## Workflow

1. **Check immediate safety first**
   - Identify instability, red flags, and time-critical threats before extended analysis.
   - If immediate evaluation or escalation may be needed, state that first and keep it separate from the differential.
   - Never let a low estimated probability erase a high-consequence diagnosis that remains clinically plausible.

2. **Clarify the task and evidence base**
   - Determine whether the case is a simulation, retrospective review, educational exercise, or real-time clinical situation.
   - Use provided records and reference materials when available.
   - For real or current clinical decisions, use current authoritative clinical guidance when tools permit. Prefer professional society guidelines, government sources, drug labeling, and peer-reviewed reviews. State when external guidance was not checked.
   - Ask only questions that materially affect safety, plausibility, testing, or management. If sufficient data exist, proceed without unnecessary clarification.

3. **Create a one-sentence problem representation**
   - Include the relevant patient context, tempo, syndrome, severity, key discriminators, and important exposures or interventions.
   - Preserve uncertainty. Do not smuggle an unproven diagnosis into the representation.

4. **Generate mechanism-based hypotheses**
   - Organize candidates by mechanism or pathophysiologic process, not by an unstructured disease list.
   - Consider common explanations, dangerous alternatives, treatment or medication effects, iatrogenic causes, and interacting or multifactorial explanations.
   - Avoid exhaustive lists that do not alter reasoning.

5. **Trace each hypothesis explicitly**
   For every leading or safety-critical hypothesis, show:
   - proposed mechanism;
   - how the mechanism could generate the observed findings;
   - evidence that increases plausibility;
   - evidence that decreases plausibility;
   - expected but absent findings, while accounting for incomplete data and imperfect sensitivity;
   - temporal fit;
   - relevant base rate and patient context when known;
   - assumptions and uncertainty.

6. **Prioritize without premature closure**
   - Separate **most plausible**, **must not miss**, and **possible but currently less supported**.
   - Do not assign invented numeric probabilities.
   - Use calibrated terms such as high, moderate, low, or indeterminate plausibility only when justified, and explain the basis.
   - Reassess whether one hypothesis explains all findings or whether multiple processes may coexist.

7. **Choose discriminating information**
   - Identify the history, examination, records, trends, bedside observations, tests, imaging, or consultations most likely to change the ranking or immediate action.
   - For each item, state which alternatives it distinguishes and how a positive, negative, or indeterminate result would update the model.
   - Prefer information gain, safety, timeliness, and actionability over indiscriminate testing.
   - Flag test limitations, pretest-probability concerns, and potential harms or burdens.

8. **Define the working model and handoff**
   - State the current working explanation as provisional.
   - List unresolved alternatives and triggers for escalation or model revision.
   - If the user asks whether an exposure truly caused an outcome, requests causal effect estimation, a DAG, an adjustment set, or formal analysis of confounding, mediation, selection, or collider bias, hand off to the parent Causal Inference skill using the handoff fields below.

## Required safeguards

- Do not present the output as a diagnosis or as a substitute for an independently qualified clinician.
- Do not recommend delaying emergency care while gathering additional information.
- Do not equate correlation, temporal sequence, treatment response, or mechanistic plausibility with proof of causation.
- Do not fabricate symptoms, examination findings, test results, prevalence, guideline recommendations, or citations.
- Distinguish patient-specific facts, general medical knowledge, inference, and unknown information.
- Avoid blame-oriented causal language for clinicians, patients, caregivers, or teams.
- For medication questions, preserve dose, route, timing, renal/hepatic function, interactions, allergies, pregnancy status, and monitoring context when available.

## Default output

Adapt length to the case but preserve these sections:

### Immediate safety priorities
State instability, red flags, urgent exclusions, and escalation needs. If none are evident from the supplied information, say that available information is insufficient to rule them out.

### Problem representation
Provide one concise sentence.

### Mechanism-based differential
For each leading or safety-critical explanation include:
- **Explanation and mechanism**
- **Why it fits**
- **Why it may not fit**
- **Plausibility:** high, moderate, low, or indeterminate, with rationale
- **Urgency:** routine, time-sensitive, or emergent, with rationale

### Highest-value discriminators
Provide a prioritized list. For each item state:
- what to obtain;
- which alternatives it distinguishes;
- how the result would change reasoning or action;
- important limitations or burdens.

### Provisional working model
Summarize the leading explanation, important competing explanations, degree of uncertainty, and conditions that would change the model.

### Next-step safety net
List escalation triggers, reassessment needs, and follow-up gaps appropriate to the context.

## Causal Inference handoff

When formal causal evaluation is needed, return:
- clinical presentation and defined outcome;
- candidate exposures or contributing factors;
- proposed mechanisms and temporal sequence;
- competing explanations;
- potential confounders, mediators, moderators, and colliders;
- supporting, contradictory, and missing evidence;
- causal question that remains unresolved;
- recommended next causal-analysis step.

## Quality check

Before responding, verify that the output:
- explains mechanisms rather than only listing diagnoses;
- separates likelihood from urgency;
- includes contradictory evidence and uncertainty;
- identifies information that would actually discriminate among alternatives;
- avoids unsupported certainty and invented evidence;
- provides an explicit safety net;
- hands off formal causal claims rather than resolving them inside this skill.

For additional consistency, consult `references/reasoning-rubric.md` when evaluating complex or high-uncertainty cases.
