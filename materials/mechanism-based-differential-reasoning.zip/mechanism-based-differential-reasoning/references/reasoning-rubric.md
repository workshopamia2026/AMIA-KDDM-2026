# Mechanism-Based Differential Reasoning Rubric

Use this rubric for complex cases, simulations, or when checking output quality.

## 1. Problem representation
- Includes relevant context, tempo, syndrome, severity, and discriminators.
- Avoids embedding an assumed diagnosis.
- Omits details that do not affect reasoning.

## 2. Mechanistic coherence
For each important hypothesis:
- The proposed mechanism can plausibly produce the observed presentation.
- The temporal sequence is coherent.
- Supporting and conflicting findings are explicit.
- Missing expected findings are interpreted cautiously.
- Multifactorial explanations are considered when one mechanism is insufficient.

## 3. Plausibility calibration
- Common conditions receive appropriate consideration without base-rate neglect.
- Rare conditions are not elevated solely because they can explain one feature.
- Dangerous conditions remain visible when the consequence of missing them is high.
- Plausibility and urgency are reported separately.
- No unsupported numeric probability is invented.

## 4. Information value
A high-value discriminator should satisfy several of these criteria:
- materially changes the ranking of alternatives;
- changes immediate management or disposition;
- helps exclude a dangerous condition;
- is timely and feasible;
- has acceptable burden and risk;
- has interpretable performance in the relevant pretest-probability range.

Avoid tests that are unlikely to change reasoning, duplicate existing information, or create foreseeable cascades without a clear decision pathway.

## 5. Safety and uncertainty
- Red flags and escalation thresholds appear first.
- Facts, inferences, and unknowns are distinguishable.
- The working model remains provisional.
- The response states what evidence would cause revision.
- The response does not replace clinician judgment or emergency evaluation.

## 6. Causal boundary
Escalate to the parent Causal Inference skill when the task shifts from explaining a presentation to estimating whether an exposure or intervention caused an outcome, selecting an adjustment set, constructing a DAG, or analyzing confounding, mediation, selection, or collider bias.
